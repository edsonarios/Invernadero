import { Component } from '@angular/core';

import { fundido } from '../../../../../animation';
@Component({
  selector: 'ngx-admin-invernadero-editar-controlador',
  //styleUrls: ['./edit.component.scss'],
  templateUrl: './editcontroller.component.html',
  animations: [fundido]
})
export class EditControllerComponent {
	
}
