import { Component } from '@angular/core';

import { fundido } from '../../../../../animation';
@Component({
  selector: 'ngx-admin-invernadero-editar-componente',
  //styleUrls: ['./edit.component.scss'],
  templateUrl: './editcomponent.component.html',
  animations: [fundido]
})
export class EditComponentComponent {
	
}
