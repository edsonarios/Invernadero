import { Component } from '@angular/core';

@Component({
  selector: 'ngx-admnistrador-componentes',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class ComponentesComponent {
}
