import { Component } from '@angular/core';

@Component({
  selector: 'ngx-admnistrador-controladores',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class ControladoresComponent {
}
