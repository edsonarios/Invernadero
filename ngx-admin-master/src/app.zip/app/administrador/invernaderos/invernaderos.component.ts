import { Component } from '@angular/core';

@Component({
  selector: 'ngx-admnistrador-Invernaderos',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class InvernaderosComponent {
}
