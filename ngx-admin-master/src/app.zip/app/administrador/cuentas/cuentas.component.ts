import { Component } from '@angular/core';

@Component({
  selector: 'ngx-admnistrador-cuentas',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class CuentasComponent {
}
