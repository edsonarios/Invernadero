import { Component } from '@angular/core';

@Component({
  selector: 'ngx-control-manual',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class ControlManualComponent {
}
