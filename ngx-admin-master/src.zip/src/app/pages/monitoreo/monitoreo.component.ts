import { Component } from '@angular/core';

@Component({
  selector: 'ngx-monitoreo',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class MonitoreoComponent {
}
