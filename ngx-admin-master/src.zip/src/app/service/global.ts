export var GLOBAL = {
	//url: 'http://173.212.235.89:3000/api/',
	//urlSocket: 'http://173.212.235.89:8080'
	//url: 'http://192.168.1.6:3000/api/',
	//urlSocket: 'http://192.168.1.6:8080'
	url: 'http://localhost:3000/api/',
	urlSocket: 'http://localhost:8080'
	

}
