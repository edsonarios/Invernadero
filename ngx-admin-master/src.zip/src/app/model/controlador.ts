export class controlador{
	constructor(
		public id: string,
		public invernaderoId: string,
		public modelo: string,
		public marca: string,
		public nroPines: string
		){}
}