export class pines{
	constructor(
		public id:string,
		public controladorId: string,
		public nroPin: string,
		public habilitado: string,
		public tipoPin: string,
		public modelo: string,
		public marca: string
		){}
}